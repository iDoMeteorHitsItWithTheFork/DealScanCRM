var app = angular.module('CRM', ['ui.router','ui.bootstrap', 'ngSanitize', 'ngResource', 'ngAnimate','ngCookies','ngAside']);
app.config(['$stateProvider', '$urlRouterProvider',
	function ($stateProvider, $urlRouterProvider,Authentication, $q) {
		$urlRouterProvider.otherwise("/login");
		$stateProvider
		  .state('login', {
			  url: '/login',
			  title: 'Login',
			  templateUrl:'app/login/loginView.html',
			  controller: 'LoginCtrl',		
		  })
		  .state('crm', {
		  	url: '/crm',
			  abstract: true,
		  	views: {
		  		'navigation@crm': {
		  			templateUrl: 'app/navigation/navigationView.html',
		  			controller: 'NavigationCtrl as Navigation'
		  		},
		  		'content': {
		  			templateUrl: 'app/navigation/content.html',
		  		},
					'sidebarNav@crm': {
						templateUrl: 'app/navigation/sidenav.html',
						controller: 'NavigationCtrl as Navigation'
					}
		  	}
		  }) 
		  .state('crm.dashboard', {
			 url:'/dashboard',
			 title: 'Dashboard',
			 views : {
				'pageContent': {
					templateUrl:'app/dashboard/dashboardView.html',
					controller: 'DashboardCtrl as Dashboard'
				},
		     }			   
		  })
		 	.state('crm.profile', {
			 url:'/dashboard',
			 title: 'Profile',
			 views : {
				'pageContent': {
					templateUrl:'app/profile/profileView.html',
					controller: 'ProfileCtrl as Profile'
				},
		     }			   
		  })
  }])
  .run(function ($rootScope, $state, $timeout, $filter) {
	 	$rootScope.$state = $state;
	    $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {});
		$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams){
			$rootScope.pageTitle = toState.title;
			$rootScope.pageName = toState.name;			
		}); 
		$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error){
			event.preventDefault();
			console.log('State Change Error');
			console.log(error);
			console.log('___ToState___');
			console.log(toState);
			console.log('___FromState___');
			console.log(fromState)
		}); 
		
				
 });


app.constant('APP_MEDIAQUERY', {
    'desktopXL': 1200,
    'desktop': 992,
    'tablet': 768,
    'mobile': 480
});
app.run(['$rootScope', '$state', '$stateParams',
function ($rootScope, $state, $stateParams) {
	
    // Attach Fastclick for eliminating the 300ms delay between a physical tap and the firing of a click event on mobile browsers
    FastClick.attach(document.body);
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;

    // GLOBAL APP SCOPE
    $rootScope.app = {
        name: 'Deal Scan', 
        author: 'Deal Scan',
        description: 'CRM Dashboard', 
        version: '1.0', 
        year: ((new Date()).getFullYear()), 
        isMobile: (function () {
            var check = false;
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                check = true;
            };
            return check;
        })(),
        defaultLayout: {
            isNavbarFixed: true, 
            isSidebarFixed: true, 
            isSidebarClosed: false, 
            isFooterFixed: false,
            isBoxedPage: false
        },
        layout: ''
    };
    $rootScope.app.layout = angular.copy($rootScope.app.defaultLayout);
}]);

 

 

 
