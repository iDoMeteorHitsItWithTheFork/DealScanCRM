app.controller('DashboardCtrl',['$scope', '$rootScope', '$timeout', '$compile', '$state', '$modal', '$window', '$filter', function ($scope, $rootScope, $timeout, $compile, $state, $modal, $window, $filter) {
	
	var _dashboard = this;
	console.log("dashboard controller loaded");
	

}]);



