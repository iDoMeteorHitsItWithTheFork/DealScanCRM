<!DOCTYPE html>
<html lang="en" ng-app="CRM" class="no-js" >
<head>
<title ng-bind="'DealScan | ' + pageTitle"></title>
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>

<link rel='stylesheet' type='text/css' href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css"/>
<link href="app/vendors/styles/angular-aside.css" rel="stylesheet" />
<link href="app/vendors/styles/simple-line-icons.css" rel="stylesheet" type="text/css" media="screen">
<link href="app/vendors/styles/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="app/vendors/styles/bootstrap-styles.css" rel="stylesheet" type="text/css"/>
<link href="app/styles/crm.css" rel="stylesheet" type="text/css"/>
<link href="app/styles/custom.css" rel="stylesheet" type="text/css"/>


</head>
<body class="ng-cloak">
<div ui-view></div>
<div ng-if="!$state.is('login')" ui-view="content" id="app" class="app-navbar-fixed app-sidebar-fixed"></div>
</body>


<script src="app/vendors/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.5/angular.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.5/angular-sanitize.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.5/angular-animate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.5/angular-resource.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.5/angular-cookies.min.js"></script>
<script src="app/vendors/angular-ui-router.min.js"></script>
<script src="app/vendors/bootstrap.js"></script>
<script src="app/vendors/ui-bootstrap-tpls-0.13.4.min.js"></script>
<script src="app/vendors/fastclick.js"></script>
<script src="app/vendors/angular-aside.js"></script>

<script src="app/main.js"></script>
<script src="app/login/login.controller.js"></script>
<script src="app/navigation/navigation.controller.js"></script>
<script src="app/navigation/navigation.directives.js"></script>
<script src="app/dashboard/dashboard.controller.js"></script>
<script src="app/profile/profile.controller.js"></script>

</html>