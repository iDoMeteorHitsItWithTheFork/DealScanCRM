app.controller('LoginCtrl', function ($scope, $rootScope, $stateParams, $state) {
	$scope.username = "DealScan@dealscan.com";
	$scope.password = "password";
	$scope.login = function(){
		$state.go("crm.dashboard");
	}	
});