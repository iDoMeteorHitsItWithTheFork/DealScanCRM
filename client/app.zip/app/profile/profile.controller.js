app.controller('ProfileCtrl',['$scope', '$rootScope', '$timeout', '$compile', '$state', '$modal', '$window', '$filter', function ($scope, $rootScope, $timeout, $compile, $state, $modal, $window, $filter) {
	
	var _profile = this;
	console.log("profile controller loaded");
	

}]);