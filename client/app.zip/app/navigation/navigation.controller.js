app.controller('NavigationCtrl', function ($scope, $rootScope, $state, $modal, $filter) {
	
	var _navigation = this;

	_navigation.go = function(state) {
      $state.go(state);
    };	

});